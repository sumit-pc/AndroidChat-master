package com.example.aymen.androidchat;



import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;

import android.support.v4.app.NotificationCompat;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.github.nkzawa.emitter.Emitter;
import com.github.nkzawa.socketio.client.IO;
import com.github.nkzawa.socketio.client.Socket;

import org.json.JSONException;
import org.json.JSONObject;

import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.List;

public class ChatBoxActivity extends AppCompatActivity {

    private SharedPreferences mPreferences;
    private String sharedPrefFile = "com.example.android.hellosharedprefs";
    public static final String NICKNAME_KEY = "application_user_nickname";

    public RecyclerView myRecylerView ;
    public List<Message> MessageList ;
    public ChatBoxAdapter chatBoxAdapter;
    public  EditText messagetxt ;
    public  Button send ;
    //declare socket object
    //private Socket socket;

    private static final String ACTION_UPDATE_NOTIFICATION = "com.android.example.notifyme.ACTION_UPDATE_NOTIFICATION";
    private static final int NOTIFICATION_ID = 0;
    private static final String PRIMARY_CHANNEL_ID = "primary_notification_channel";
    private NotificationManager mNotifyManager;

    public static String Nickname ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chat_box);

        mPreferences = getSharedPreferences(sharedPrefFile, MODE_PRIVATE);

        messagetxt = (EditText) findViewById(R.id.message) ;
        send = (Button)findViewById(R.id.send);
        // get the nickame of the user
        try{
            Nickname= (String)getIntent().getExtras().getString(MainActivity.NICKNAME);
            SharedPreferences.Editor preferencesEditor = mPreferences.edit();
            preferencesEditor.putString(NICKNAME_KEY, Nickname);
            preferencesEditor.apply();
        }
        catch (Exception e)
        {
            Nickname = mPreferences.getString(NICKNAME_KEY,"");
        }

        //connect you socket client to the server
        /* socket = IO.socket("http://203.193.171.133:56455");
         socket.connect();*/
        ClientSocket.socketIO.emit("join", Nickname);
        //setting up recyler
        MessageList = new ArrayList<>();
        myRecylerView = (RecyclerView) findViewById(R.id.messagelist);
        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(getApplicationContext());
        myRecylerView.setLayoutManager(mLayoutManager);
        ((LinearLayoutManager) mLayoutManager).setStackFromEnd(true);
        myRecylerView.setItemAnimator(new DefaultItemAnimator());



        // message send action
        send.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //retrieve the nickname and the message content and fire the event messagedetection
                if(!messagetxt.getText().toString().isEmpty()){
                    ClientSocket.socketIO.emit("messagedetection",Nickname,messagetxt.getText().toString());
                    messagetxt.setText(" ");
                }


            }
        });

        //implementing socket listeners
        ClientSocket.socketIO.on("userjoinedthechat", new Emitter.Listener() {
            @Override
            public void call(final Object... args) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        String data = (String) args[0];

                        Toast.makeText(ChatBoxActivity.this,data,Toast.LENGTH_LONG).show();

                    }
                });
            }
        });
        ClientSocket.socketIO.on("userdisconnect", new Emitter.Listener() {
            @Override
            public void call(final Object... args) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        String data = (String) args[0];

                        Toast.makeText(ChatBoxActivity.this,data,Toast.LENGTH_LONG).show();

                    }
                });
            }
        });
        ClientSocket.socketIO.on("message", new Emitter.Listener() {
            @Override
            public void call(final Object... args) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        JSONObject data = (JSONObject) args[0];
                        try {


                            String nickname = data.getString("senderNickname");
                            String message = data.getString("message");


                            Message m = new Message(nickname,message);


                            MessageList.add(m);


                            chatBoxAdapter = new ChatBoxAdapter(MessageList);


                            chatBoxAdapter.notifyDataSetChanged();


                            myRecylerView.setAdapter(chatBoxAdapter);

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }


                    }
                });
            }
        });
    }

    @Override
    protected void onPause() {
        super.onPause();
        /*ClientSocket.socketIO.disconnect();
        Intent background = new Intent(ChatBoxActivity.this, AppBackgroundService.class);
        background.putExtra(MainActivity.NICKNAME,Nickname);
        startService(background);*/
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        /*ClientSocket.socketIO.disconnect();
        Intent background = new Intent(ChatBoxActivity.this, AppBackgroundService.class);
        background.putExtra(MainActivity.NICKNAME,Nickname);
        startService(background);*/
  }

}
