package com.example.aymen.androidchat;

import com.github.nkzawa.socketio.client.IO;
import com.github.nkzawa.socketio.client.Socket;

import java.net.URISyntaxException;

public class ClientSocket {

    public static com.github.nkzawa.socketio.client.Socket socketIO;

}
